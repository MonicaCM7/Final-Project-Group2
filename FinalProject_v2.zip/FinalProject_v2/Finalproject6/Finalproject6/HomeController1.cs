﻿using Microsoft.AspNetCore.Mvc;

namespace Finalproject6
{
    public class HomeController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
