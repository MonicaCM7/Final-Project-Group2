﻿using Microsoft.AspNetCore.Mvc;

namespace Finalproject6
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
